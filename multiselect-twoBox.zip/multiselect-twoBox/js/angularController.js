var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {

	//AJAX configuration to access API for States and Cities
	var getStates = function(){
		return $http({
			method : "GET",
			url : "https://raw.githubusercontent.com/Ujjwal1140/multiselect/master/pincodesIndia.json",
			cache: true
		})
	}
 
	//Array to store States
	$scope.states = ["Select State"];
	$scope.selectedState = $scope.states[0];
	
	//Array to store selected pin codes
	$scope.selectedPincodes = [];

	
	//Array to store Pin codes
	$scope.pincodes = []
	$scope.showItems = 10;

	//Get states and pin codes
	getStates().then(function(response1) {		
		$scope.responseData = response1.data;
		//Get States
		angular.forEach($scope.responseData, function(value,index){
			if($scope.states.indexOf(value.State) == -1){
				$scope.states.push(value.State);
			}
		})
		
		//Get Pin codes
		$scope.pincodes = $scope.responseData;
	});
	
	//Select pin codes
    $scope.addPincodes = function () {
    	angular.forEach($scope.selectPincodes, function(value1,index1){
    		value1 = angular.fromJson(value1);
    		$scope.selectedPincodes.push(value1);
	    	angular.forEach($scope.pincodes, function(value,index){
	    	    if(value1.Location == value.Location && value1.PinCode == value.PinCode){
	    			$scope.pincodes.splice(index,1);
	    		}
	    	})
    	});
    	$scope.selectPincodes = null;
    }

    //Remove pin codes
    $scope.removeAddedPincodes = function() {
		angular.forEach($scope.removePincodes, function(valueSelected,indexSelected){
			valueSelected = angular.fromJson(valueSelected);
	    	angular.forEach($scope.selectedPincodes, function(value,index){
	    	    if(value.Location == valueSelected.Location && value.PinCode == valueSelected.PinCode){
	    			$scope.selectedPincodes.splice(value,1);
	    			$scope.pincodes.unshift(valueSelected);
	    		}
	    	})
    	})
    }

	//Find pin codes for selected state
	$scope.getPincodesFor = function(selectedState){
		$scope.pincodes = [];
		$scope.showItems = 10;

		if(selectedState != "Select State"){
			angular.forEach($scope.responseData, function(value,index){
				if(selectedState == value.State){
					$scope.pincodes.push(value)
				}
			});
		}
		else {
			$scope.pincodes =  $scope.responseData;
		}
	}

	//Load 10 more item each time the scroll reaches bottom
	angular.element("#search").on('scroll', function(event){
		var element = event.target;
	    if (element.scrollHeight - element.scrollTop === element.clientHeight)
	    {
    		$scope.showItems = $scope.showItems + 10
	    }
	});
	
});
//Custom directive to updated model data on scroll event
app.directive('scroller', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.bind('scroll', function () {
                scope.$apply();
            });
        }
    };
});