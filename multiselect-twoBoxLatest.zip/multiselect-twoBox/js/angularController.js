var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {

	//AJAX configuration to access API for States and Cities
	var getStates = function(){
		return $http({
			method : "GET",
			url : "https://raw.githubusercontent.com/Ujjwal1140/multiselect/master/pincodesIndia.json",
			cache: true
		})
	}
 
	//Array to store States
	$scope.states = ["Select State"];
	$scope.selectedState = $scope.states[0];
	
	//Array to store selected pin codes
	$scope.selectedPincodes = [];

	
	//Array to store Pin codes
	$scope.pincodes = []
	$scope.showItems = 10;

	//Get list of states and cities
	getStates().then(function(response1) {		
		$scope.responseData = response1.data;
		//Get list of States
		angular.forEach($scope.responseData, function(value,index){
			if($scope.states.indexOf(value.State) == -1){
				$scope.states.push(value.State);
			}
		})

		$scope.pincodes = $scope.responseData;
	});
	
	//Select pin codes
    $scope.addPincodes = function () {
    	angular.forEach($scope.selectPincodes, function(value,index){
    		value = angular.fromJson(value);
    		$scope.selectedPincodes.push(
				{
					PinCode:value.PinCode,
					Location:value.Location
				}
			);    		
    	})
    }


	//Find pin codes for selected state
	$scope.getPincodesFor = function(selectedState){
		$scope.pincodes = [];
		$scope.showItems = 10;

		angular.forEach($scope.responseData, function(value,index){
			if(selectedState == value.State && selectedState != "Select State"){
				$scope.pincodes.push($scope.responseData[index])
			}
			else if (selectedState == "Select State"){
				$scope.pincodes = $scope.responseData;
			}
		});
		angular.element("#search").scrollTop = 0;
	}

	angular.element("#search").on('scroll', function(event){
		var element = event.target;
	    if (element.scrollHeight - element.scrollTop === element.clientHeight)
	    {
    		$scope.showItems = $scope.showItems + 10
	    }
	});
});
app.directive('scroller', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.bind('scroll', function () {
                scope.$apply();
            });
        }
    };
});